#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;

// ---------------------------------------------------------------------------
// PlayLayer hooks: speedhack, noclip, and the info overlay.
// All behaviour is driven by the mod's settings (edit them from Geode's
// in-game mod list, no extra UI needed).
// ---------------------------------------------------------------------------
class $modify(ModMenuPlayLayer, PlayLayer) {
    struct Fields {
        CCLabelBMFont* infoLabel = nullptr;
        float frameTimer = 0.f;
        int frameCount = 0;
        float fps = 0.f;
        CCPoint lastPos = CCPoint(0, 0);
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) {
            return false;
        }

        if (Mod::get()->getSettingValue<bool>("show-overlay")) {
            auto label = CCLabelBMFont::create("FPS: --", "chatFont.fnt");
            label->setAnchorPoint({0.f, 1.f});
            label->setScale(0.5f);
            label->setPosition({10.f, CCDirector::sharedDirector()->getWinSize().height - 10.f});
            label->setID("mod-menu-info-label"_spr);
            label->setZOrder(1000);
            // Keep it on screen regardless of camera movement.
            this->addChild(label, 1000);
            m_fields->infoLabel = label;
        }

        return true;
    }

    void update(float dt) {
        // Apply speedhack every frame so changing the setting mid-level
        // takes effect immediately.
        auto speed = Mod::get()->getSettingValue<double>("speedhack");
        CCDirector::sharedDirector()->getScheduler()->setTimeScale(static_cast<float>(speed));

        PlayLayer::update(dt);

        if (m_fields->infoLabel && m_player1) {
            m_fields->frameTimer += dt;
            m_fields->frameCount++;
            if (m_fields->frameTimer >= 0.5f) {
                m_fields->fps = m_fields->frameCount / m_fields->frameTimer;
                m_fields->frameCount = 0;
                m_fields->frameTimer = 0.f;
            }

            auto pos = m_player1->getPosition();
            auto speedPxPerSec = m_fields->lastPos.x > 0.f
                ? (pos - m_fields->lastPos).getLength() / dt
                : 0.f;
            m_fields->lastPos = pos;

            m_fields->infoLabel->setString(fmt::format(
                "FPS: {:.0f}\nX: {:.0f}  Y: {:.0f}\nSpeed: {:.0f} px/s",
                m_fields->fps, pos.x, pos.y, speedPxPerSec
            ).c_str());
        }
    }

    // destroyPlayer is called whenever the player dies. When noclip is on
    // we simply swallow the call so death never triggers.
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        if (Mod::get()->getSettingValue<bool>("noclip")) {
            return;
        }
        PlayLayer::destroyPlayer(player, object);
    }

    void onQuit() {
        // Always reset time scale so speedhack doesn't leak into menus.
        CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.f);
        PlayLayer::onQuit();
    }
};
