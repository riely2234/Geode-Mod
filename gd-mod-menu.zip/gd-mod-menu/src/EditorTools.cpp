#include <Geode/Geode.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>
#include <Geode/ui/GeodeUI.hpp>

using namespace geode::prelude;

// ---------------------------------------------------------------------------
// Helpers for reading/writing the raw level object string.
//
// NOTE: GD's level format stores objects separated by ';', each object as
// comma-separated key,value pairs. Key "2" is the X position. This matches
// the format used by every existing level-string editor mod, but if a GD
// update changes it, this is the only place you'd need to adjust.
// ---------------------------------------------------------------------------
namespace LevelMerge {

    float getObjectX(std::string const& obj) {
        auto parts = string::split(obj, ",");
        for (size_t i = 0; i + 1 < parts.size(); i += 2) {
            if (parts[i] == "2") {
                return numFromString<float>(parts[i + 1]).unwrapOr(0.f);
            }
        }
        return 0.f;
    }

    std::string shiftObjectX(std::string const& obj, float offset) {
        auto parts = string::split(obj, ",");
        std::string result;
        for (size_t i = 0; i + 1 < parts.size(); i += 2) {
            if (i > 0) result += ",";
            result += parts[i] + "," + (
                parts[i] == "2"
                    ? std::to_string(numFromString<float>(parts[i + 1]).unwrapOr(0.f) + offset)
                    : parts[i + 1]
            );
        }
        return result;
    }

    // Merges levelBString onto the end of levelAString, shifting every
    // object in B to the right so nothing overlaps A. Returns the combined
    // object string, ready to be written back into a GJGameLevel.
    std::string mergeLevelStrings(std::string const& levelAString, std::string const& levelBString) {
        auto objsA = string::split(levelAString, ";");
        auto objsB = string::split(levelBString, ";");

        float maxX = 0.f;
        for (auto& obj : objsA) {
            if (obj.empty()) continue;
            maxX = std::max(maxX, getObjectX(obj));
        }

        const float gap = 300.f; // breathing room between the two levels
        std::string merged = levelAString;
        if (!merged.empty() && merged.back() != ';') merged += ";";

        for (auto& obj : objsB) {
            if (obj.empty()) continue;
            merged += shiftObjectX(obj, maxX + gap) + ";";
        }

        return merged;
    }
}

// ---------------------------------------------------------------------------
// Popup: pick a saved local level to merge into the level currently open
// in the editor.
// ---------------------------------------------------------------------------
class MergeLevelPopup : public geode::Popup<LevelEditorLayer*> {
protected:
    LevelEditorLayer* m_editorLayer;

    bool setup(LevelEditorLayer* editor) override {
        m_editorLayer = editor;
        this->setTitle("Merge Level");

        auto listBG = CCLayerColor::create({0, 0, 0, 100}, 220.f, 180.f);
        listBG->setPosition({m_mainLayer->getContentSize().width / 2 - 110.f, 45.f});
        m_mainLayer->addChild(listBG);

        auto levels = GameLevelManager::sharedState()->m_localLevels;
        float y = 165.f;
        for (int i = 0; i < levels->count() && i < 6; i++) {
            auto level = static_cast<GJGameLevel*>(levels->objectAtIndex(i));
            auto label = CCLabelBMFont::create(level->m_levelName.c_str(), "bigFont.fnt");
            label->setScale(0.45f);

            auto btn = CCMenuItemSpriteExtra::create(
                label, this, menu_selector(MergeLevelPopup::onPickLevel)
            );
            btn->setTag(i);
            btn->setPosition({m_mainLayer->getContentSize().width / 2, y});

            auto menu = CCMenu::create();
            menu->addChild(btn);
            menu->setPosition({0, 0});
            m_mainLayer->addChild(menu);

            y -= 26.f;
        }

        return true;
    }

    void onPickLevel(CCObject* sender) {
        auto tag = static_cast<CCMenuItemSpriteExtra*>(sender)->getTag();
        auto levels = GameLevelManager::sharedState()->m_localLevels;
        auto otherLevel = static_cast<GJGameLevel*>(levels->objectAtIndex(tag));

        auto currentLevel = m_editorLayer->m_level;

        // Both level strings are stored zlib/gzip compressed on disk; decompress,
        // merge as plain text, then feed the result back to the editor.
        auto currentObjString = ZipUtils::decompressString(currentLevel->m_levelString, false, 0);
        auto otherObjString = ZipUtils::decompressString(otherLevel->m_levelString, false, 0);

        auto merged = LevelMerge::mergeLevelStrings(currentObjString, otherObjString);

        currentLevel->m_levelString = ZipUtils::compressString(merged, false);

        FLAlertLayer::create(
            "Merge Level",
            "Merged! Reopen the level (or the editor) to load the combined objects.",
            "OK"
        )->show();

        this->onClose(nullptr);
    }

public:
    static MergeLevelPopup* create(LevelEditorLayer* editor) {
        auto ret = new MergeLevelPopup();
        if (ret->initAnchored(280.f, 240.f, editor)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

// ---------------------------------------------------------------------------
// Adds a toolbar button in the editor to open the merge popup / QoL tools.
// ---------------------------------------------------------------------------
class $modify(ModMenuEditorLayer, LevelEditorLayer) {
    bool init(GJGameLevel* level) {
        if (!LevelEditorLayer::init(level)) {
            return false;
        }

        if (Mod::get()->getSettingValue<bool>("editor-qol")) {
            auto menu = this->getChildByID("editor-buttons-menu");
            if (menu) {
                auto sprite = ButtonSprite::create("Merge");
                sprite->setScale(0.6f);
                auto btn = CCMenuItemSpriteExtra::create(
                    sprite, this, menu_selector(ModMenuEditorLayer::onOpenMerge)
                );
                btn->setID("mod-menu-merge-button"_spr);
                menu->addChild(btn);
                menu->updateLayout();
            }
        }

        return true;
    }

    void onOpenMerge(CCObject*) {
        MergeLevelPopup::create(this)->show();
    }
};
