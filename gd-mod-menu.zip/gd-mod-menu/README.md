# GD Mod Menu (Geode)

A starter Geode mod for Geometry Dash with:

- **Speedhack** — adjustable game speed multiplier
- **Noclip** — no death on collision, for practice
- **FPS / player info overlay** — shows FPS, position, and speed while playing
- **Editor QoL button** — adds a "Merge" button to the level editor toolbar
- **Level merging** — combines the objects of the currently-open editor level with a saved local level, offsetting the second one so nothing overlaps

All toggles/sliders live in Geode's normal **mod settings screen** (tap the
mod in Geode's mod list) — no custom in-game UI to maintain, and it stays
compatible with other mods.

## Why you have to build this yourself

This is real, compiled game code — it hooks directly into Geometry Dash's
internals. That means it has to be compiled *against your exact GD version*
using the Geode SDK and (for Android) the Android NDK. There's no way to
hand you a working binary without that toolchain, and I can't run it here.
The good news: this is a one-time setup and Geode's CLI automates most of it.

## Build steps (do this on a PC — Windows or Linux/macOS)

1. **Install the Geode CLI**
   ```
   # See: https://docs.geode-sdk.org/getting-started/geode-cli/
   ```
   Follow the official installer for your OS from the link above.

2. **Install the Geode SDK**
   ```
   geode sdk install
   ```

3. **Set up Android build support** (needed since you want this on mobile)
   ```
   geode sdk install-loader
   ```
   Then follow Geode's Android setup guide to install the NDK and configure
   `ANDROID_NDK_ROOT`: https://docs.geode-sdk.org/getting-started/create-mod/#android

4. **Build**
   From this project's folder:
   ```
   geode build --platform android64
   ```
   (Use `android32` too if you want to support older devices, or no flag
   to build a Windows PC version to test faster first — testing on PC is
   much quicker than round-tripping to a phone.)

5. **Grab the output `.geode` file**
   It'll land in `build/android64/bin/gd-mod-menu.geode` (path varies slightly
   by platform).

## Installing on your phone

1. Copy the `.geode` file to your phone (via USB, cloud drive, etc.)
2. Open Geode in Geometry Dash → the folder/import icon → select the file
   — or drop it directly into the Geode `mods/` folder if you have file
   access (Android: `/Android/data/com.geode.launcher/files/game/geode/mods/` on
   the Geode Android launcher).
3. Restart the game. Find "GD Mod Menu" in Geode's mod list to access settings.

## Honest caveats

- **GD updates can break hooks.** `destroyPlayer`, `update`, and the editor
  button ID (`editor-buttons-menu`) are based on current Geode bindings —
  if `geode build` throws errors after a GD update, that's the SDK's
  bindings needing a refresh, not something wrong with this approach.
- **The level-merge feature touches raw level data.** I strongly recommend
  duplicating the level before merging (use GD's built-in "Copy" on the
  level in your local levels list) — a bug in a hand-written string merge
  could corrupt a level otherwise.
- If a specific hook doesn't compile against your GD version, the fastest
  fix is checking the function signature in Geode's bindings browser
  (https://docs.geode-sdk.org/classes/PlayLayer/) or asking in the
  [Geode Discord](https://discord.gg/9e43WMKzhp) — that community is very
  active and used to exactly this kind of question.

## File structure

```
gd-mod-menu/
├── mod.json          # metadata + settings schema (drives the settings UI)
├── CMakeLists.txt     # build config
└── src/
    ├── main.cpp        # speedhack, noclip, FPS/player overlay
    └── EditorTools.cpp # editor button + level merge popup
```
